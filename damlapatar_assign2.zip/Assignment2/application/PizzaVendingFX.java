package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.FileChooser.ExtensionFilter;

public class PizzaVendingFX extends Application {
	// Declare components that require class scope
	private ListView<String> menu_List;
	private ListView<String> order_List;
	private Label totalLabel;
	double totalPrice = 0;
	public Button add_Button;
	public Button removeButton;
	public Button clearButton;
	public Button payButton;
	public Button okButton;
	public Button cancelButton;
	Label confirmLabel;

	// Constructor
	public PizzaVendingFX() {
		// instantiate components
		// create the buttons
		add_Button = new Button("Add to Order");
		removeButton = new Button("Remove from Order");
		clearButton = new Button("Clear Order");
		payButton = new Button("Pay");
		okButton = new Button("OK");
		cancelButton = new Button("Cancel");
		order_List = new ListView<>();
		menu_List = new ListView<>();
		// When reading a file using BufferedReader, we open the file using the
		// FileReader class.
		// Next, we build the BufferedReader on top of the FileReader and pass the data
		// to the buffer.
		// In this way, we can read data from the buffer line by line using the
		// readLine() method.
		try (BufferedReader br = new BufferedReader(new FileReader("Assets/pizzamenu.csv"))) {
			String line;
			while ((line = br.readLine()) != null) {
				String[] parts = line.split(",");
				if (parts.length == 2) {
					// Add menu item to the menuList with the format "Pizza Name - $Price"
					menu_List.getItems().add(parts[0] + " - $" + parts[1]);
				}
			}
		} catch (IOException e) {
			System.err.println("Error reading pizzamenu.csv");
			e.printStackTrace();
		}

	}

	// Event handling
	@Override

	public void init() {
		// Create the add, remove, and clear pay okay and cancel buttons
		add_Button.setOnAction(e -> {
			String selectedItem = menu_List.getSelectionModel().getSelectedItem();
			if (selectedItem != null && !order_List.getItems().contains(selectedItem)) {
				order_List.getItems().add(selectedItem);
				calculation_Total(selectedItem, true);
			}
		});
		removeButton.setOnAction(e -> {
			String selectedItem = order_List.getSelectionModel().getSelectedItem();
			if (selectedItem != null) {
				order_List.getItems().remove(selectedItem);
				calculation_Total(selectedItem, false);
			}
		});
		clearButton.setOnAction(e -> {
			order_List.getItems().clear();
			totalLabel.setText("Total: $0.00");
			totalPrice = 0;
		});
		// Create the pay button
		payButton.setOnAction(e -> {
			Stage paymentStage = new Stage();
			paymentStage.setTitle("Payment confirmation");

		});
		// Create the OK and Cancel buttons
		okButton.setOnAction(event -> {
			Stage paymentStage = new Stage();
			paymentStage.close();
			clearButton.fire();
		});
		cancelButton.setOnAction(event -> {
			Stage paymentStage = new Stage();
			paymentStage.close();
		});
		// Create the label for the payment confirmation
		Label confirmLabel = new Label("Please confirm your payment of $" + String.format("%.2f", totalPrice));
	}
//this method is for total price calculation
	
	private void calculation_Total(String item, boolean isAdd) {
	    Pattern pattern = Pattern.compile(" - \\$(\\d+\\.\\d{2})$");
	    Matcher matcher = pattern.matcher(item);
	    if (matcher.find()) {
	        double price = Double.parseDouble(matcher.group(1));
	        totalPrice += isAdd ? price : -price;
	        totalLabel.setText(String.format("Total: $%.2f", totalPrice));
	    }
	}
	

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub

		// Create the HBox for the buttons
		VBox buttonBox = new VBox(10, add_Button, removeButton, clearButton);
		buttonBox.setAlignment(Pos.CENTER);

		// Create the label for the total price
		totalLabel = new Label("Total: $0.00 ");

		// Create the pay button
		Button payButton = new Button("Pay");
		payButton.setOnAction(e -> {
			Stage paymentStage = new Stage();
			paymentStage.setTitle("Payment Confirmation");

			// Create the label for the payment confirmation
			Alert alert=new Alert(AlertType.INFORMATION);	
			Label confirmLabel = new Label("Please confirm your payment of $" + String.format("%.2f", totalPrice));			
		

			// Create the OK and Cancel buttons
			Button okButton = new Button("OK");
			okButton.setOnAction(event -> {				
				paymentStage.close();
				clearButton.fire();
			});
			
	        
			Button cancelButton = new Button("Cancel");
			cancelButton.setOnAction(event -> paymentStage.close());

			// Create the HBox for the buttons
			HBox paymentButtonBox = new HBox(10, okButton, cancelButton);
			paymentButtonBox.setAlignment(Pos.CENTER);

			// Create the BorderPane for the payment confirmation scene
			BorderPane paymentPane = new BorderPane(confirmLabel, null, null, paymentButtonBox, null);
			paymentPane.setPadding(new Insets(10));

			Scene paymentScene = new Scene(paymentPane, 310, 130);
			paymentStage.setScene(paymentScene);
			paymentStage.showAndWait();
		});

		// Create the HBox for the total price and pay button
		HBox totalBox = new HBox(10, totalLabel, payButton);
		totalBox.setAlignment(Pos.CENTER_LEFT);

		// Create the BorderPane for the main scene
		BorderPane mainPane = new BorderPane();
		mainPane.setLeft(menu_List);
		mainPane.setCenter(buttonBox);
		mainPane.setRight(order_List);
		mainPane.setBottom(totalBox);
		mainPane.setPadding(new Insets(30));

		Scene scene = new Scene(mainPane, 680, 500);
		primaryStage.setTitle("Pizza Vending FX Project");
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}
